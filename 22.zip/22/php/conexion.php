<?php
    $conexion=mysqli_connect("localhost","root","mario14y15.","restaurante");
    $conexion->set_charset("utf8");
 
?>